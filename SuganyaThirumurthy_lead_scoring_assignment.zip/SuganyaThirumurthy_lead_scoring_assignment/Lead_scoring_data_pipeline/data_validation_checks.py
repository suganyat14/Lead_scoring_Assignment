'''
filename: data_validation_checks.py
functions: raw_data_schema_check(), model_input_schema_check()
creator: Suganya Thirumurthy
Version: 1
'''
"""
Import necessary modules
############################################################################## 
"""
import pandas as pd
import os
import sqlite3
from sqlite3 import Error
from Lead_scoring_data_pipeline.constants import *
from Lead_scoring_data_pipeline.schema import *
###############################################################################
# Define function to validate raw data's schema
############################################################################### 

def raw_data_schema_check():
    '''
    This function check if all the columns mentioned in schema.py are present in
    leadscoring.csv file or not.

   
    INPUTS
        DATA_DIRECTORY : path of the directory where 'leadscoring.csv' 
                        file is present
        raw_data_schema : schema of raw data in the form of list/tuple as present 
                          in 'schema.py'

    OUTPUT
        If the schema is in line then prints 
        'Raw datas schema is in line with the schema present in schema.py' 
        else prints
        'Raw datas schema is NOT in line with the schema present in schema.py'

    
    SAMPLE USAGE
        raw_data_schema_check
    '''
    print ("Connecting to database")
    cnx = sqlite3.connect(DB_PATH+DB_FILE_NAME)
    print ("Reading data from loaded_data table")
    loaded_data = pd.read_sql('select * from loaded_data', cnx)
    loaded_data_columns = list(loaded_data.columns)
    print("loaded_data column length: ", len(loaded_data_columns))
    print("raw_data_schema length: ", len(raw_data_schema))
    
    mismatch_col = 0
    for col in raw_data_schema:
        if col not in loaded_data_columns:
            print("column mismatch: ", col)
            mismatch_col = 1
            
    if mismatch_col == 0:
        print("Raw datas schema is in line with the schema present in schema.py")
    else:
        print("Raw datas schema is NOT in line with the schema present in schema.py")
        
    cnx.close()   

###############################################################################
# Define function to validate model's input schema
############################################################################### 

def model_input_schema_check():
    '''
    This function check if all the columns mentioned in model_input_schema in 
    schema.py are present in table named in 'model_input' in db file.

   
    INPUTS
        DB_FILE_NAME : Name of the database file
        DB_PATH : path where the db file should be present
        model_input_schema : schema of models input data in the form of list/tuple
                          present as in 'schema.py'

    OUTPUT
        If the schema is in line then prints 
        'Models input schema is in line with the schema present in schema.py'
        else prints
        'Models input schema is NOT in line with the schema present in schema.py'
    
    SAMPLE USAGE
        raw_data_schema_check
    '''
    
    print ("Connecting to database")
    cnx = sqlite3.connect(DB_PATH+DB_FILE_NAME)
    print ("Reading data from model_input table")
    model_col_sql = pd.read_sql('select * from model_input', cnx)
    model_col = list(model_col_sql.columns)    
    print("model_input column length: ", len(model_col))
    print("raw_data_schema length: ", len(model_input_schema))

    mismatch_col = 0
    for col in model_input_schema:
        if col not in model_col_sql:
            print("column mismatch: ", col)
            mismatch_col = 1
            
    if mismatch_col == 0:
        print("Models input schema is in line with the schema present in schema.py")
    else:
        print("Models input schema is NOT in line with the schema present in schema.py")
        
    cnx.close()
    
    
